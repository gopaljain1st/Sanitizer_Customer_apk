package my.springbliss.grocery.fcm;

public interface ServerKey
{
    static final String  CUSTOMER_KEY="AAAA0ogQuUM:APA91bEDNizi-KocLHuSRArs7S73cpJzpKDCHKH034Ge3nul5Uw6stPTvCGjEz1GSUx6NVLUy_exjCrkJE6B5vR05iUY4_xPwGGfa9D_d2SjrF57mS55HIqKIl5PnsWGdgi-ra45VfJ5";
    static final String    SELLER_KEY="AAAAORxIvS0:APA91bGGskLsJyjtEBobTbxmIVeFMuCV2ebUdSAqWtDzMBYnFO6Ncyhs3XhHv40v6CdMHvfn8MksVk9h1d9U4HqRGeEVgT-53KbqLZROKZlv-cnEOBq4rhmiV-uOajOpB_Li7NdFFZsL";
}
